import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RootHomeComponent } from './root-home/root-home.component';
import { Router, RouterModule } from '@angular/router';
import { RootLayoutComponent } from '../layout/root-layout/root-layout.component';
import { HomeComponent } from '../pages/home/home.component';
import { RootAboutComponent } from './root-about/root-about.component';



@NgModule({
  declarations: [
    RootHomeComponent,
    RootAboutComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
        {path:"",component:RootHomeComponent},
        {path:"home",component:RootHomeComponent},
        {path:"about",component:RootAboutComponent}
    ])
  ]
})
export class RootModule { }
