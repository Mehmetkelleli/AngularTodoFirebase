import { Component } from '@angular/core';

@Component({
  selector: 'app-root-about',
  templateUrl: './root-about.component.html',
  styleUrls: ['./root-about.component.css']
})
export class RootAboutComponent {

}
