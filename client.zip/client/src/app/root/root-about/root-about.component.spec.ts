import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RootAboutComponent } from './root-about.component';

describe('RootAboutComponent', () => {
  let component: RootAboutComponent;
  let fixture: ComponentFixture<RootAboutComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RootAboutComponent]
    });
    fixture = TestBed.createComponent(RootAboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
