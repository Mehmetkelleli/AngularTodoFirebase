import { Component } from '@angular/core';

@Component({
  selector: 'app-root-home',
  templateUrl: './root-home.component.html',
  styleUrls: ['./root-home.component.css']
})
export class RootHomeComponent {

}
